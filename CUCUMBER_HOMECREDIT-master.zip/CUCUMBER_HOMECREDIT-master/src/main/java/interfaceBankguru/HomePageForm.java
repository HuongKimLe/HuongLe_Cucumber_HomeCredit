package interfaceBankguru;

public class HomePageForm {
	public static final String WELCOME_TEXT = "//marquee[text() = \"Welcome To Manager's Page of Guru99 Bank\"]";
}
