package interfaceBankguru;

public class EditCustomerPageUI {
	public static final String DYNAMIC_CHECKBOX_INPUTFORM = "//input[@type='radio' and @value='%s' %s]";
}
