package interfaceBankguru;

public class NewCustomerPageUI {
	
}
