package interfaceBankguru;

public class RegisterForm {
	public static final String EMAIL_TEXTBOX = "//input[@name = 'emailid']";
	public static final String SUBMIT_BUTTON = "//input[@type= 'submit']";
	public static final String USERID_TEXT = "//td[text() = 'User ID :']/following-sibling::td";
	public static final String PASSWORD_TEXT = "//td[text() = 'Password :']/following-sibling::td";

}
