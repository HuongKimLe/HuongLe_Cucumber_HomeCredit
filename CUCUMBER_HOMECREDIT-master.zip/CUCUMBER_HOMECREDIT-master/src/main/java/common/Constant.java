package common;

public class Constant {

	public static final String DEV_URL = "http://demo.guru99.com/v4/";
}
