package common;

import org.openqa.selenium.WebDriver;

public class GlobalVariable {
	public static String generalUserID;
	public static String generalPassword;
	public static WebDriver glbDriver;
}
