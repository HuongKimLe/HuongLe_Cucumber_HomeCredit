package page.object;

import org.openqa.selenium.WebDriver;

import common.AbstractPage;

public class DeleteCustomerPageObject extends AbstractPage {
	WebDriver driver;

	public DeleteCustomerPageObject(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
}
